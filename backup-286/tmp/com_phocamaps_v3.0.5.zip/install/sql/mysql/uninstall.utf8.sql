DROP TABLE IF EXISTS `#__phocamaps_map`;
DROP TABLE IF EXISTS `#__phocamaps_marker`;
DROP TABLE IF EXISTS `#__phocamaps_icon`;
